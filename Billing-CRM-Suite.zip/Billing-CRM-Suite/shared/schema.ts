import { pgTable, text, serial, integer, timestamp, numeric } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// === Customers & Vendors (CRM) ===
export const customers = pgTable("customers", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email"),
  phone: text("phone"),
  address: text("address"),
  gstin: text("gstin"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const vendors = pgTable("vendors", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email"),
  phone: text("phone"),
  address: text("address"),
  gstin: text("gstin"),
  createdAt: timestamp("created_at").defaultNow(),
});

// === Invoices ===
export const invoices = pgTable("invoices", {
  id: serial("id").primaryKey(),
  customerId: integer("customer_id").notNull(),
  number: text("number").notNull(),
  date: timestamp("date").notNull(),
  dueDate: timestamp("due_date"),
  status: text("status").notNull().default("Draft"), // Draft, Sent, Paid, Overdue
  totalAmount: numeric("total_amount").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const invoiceItems = pgTable("invoice_items", {
  id: serial("id").primaryKey(),
  invoiceId: integer("invoice_id").notNull(),
  description: text("description").notNull(),
  quantity: integer("quantity").notNull(),
  unitPrice: numeric("unit_price").notNull(),
  amount: numeric("amount").notNull(),
});

// === Delivery Challans ===
export const deliveryChallans = pgTable("delivery_challans", {
  id: serial("id").primaryKey(),
  customerId: integer("customer_id").notNull(),
  number: text("number").notNull(),
  date: timestamp("date").notNull(),
  status: text("status").notNull().default("Pending"), // Pending, Delivered
  createdAt: timestamp("created_at").defaultNow(),
});

export const deliveryChallanItems = pgTable("delivery_challan_items", {
  id: serial("id").primaryKey(),
  challanId: integer("challan_id").notNull(),
  description: text("description").notNull(),
  quantity: integer("quantity").notNull(),
});

// === RELATIONS ===
export const customersRelations = relations(customers, ({ many }) => ({
  invoices: many(invoices),
  challans: many(deliveryChallans),
}));

export const invoicesRelations = relations(invoices, ({ one, many }) => ({
  customer: one(customers, {
    fields: [invoices.customerId],
    references: [customers.id],
  }),
  items: many(invoiceItems),
}));

export const invoiceItemsRelations = relations(invoiceItems, ({ one }) => ({
  invoice: one(invoices, {
    fields: [invoiceItems.invoiceId],
    references: [invoices.id],
  }),
}));

export const deliveryChallansRelations = relations(deliveryChallans, ({ one, many }) => ({
  customer: one(customers, {
    fields: [deliveryChallans.customerId],
    references: [customers.id],
  }),
  items: many(deliveryChallanItems),
}));

export const deliveryChallanItemsRelations = relations(deliveryChallanItems, ({ one }) => ({
  challan: one(deliveryChallans, {
    fields: [deliveryChallanItems.challanId],
    references: [deliveryChallans.id],
  }),
}));

// === SCHEMAS ===
export const insertCustomerSchema = createInsertSchema(customers).omit({ id: true, createdAt: true });
export const insertVendorSchema = createInsertSchema(vendors).omit({ id: true, createdAt: true });

// For invoices, we need to handle items separately in the API, but base schema is useful
export const insertInvoiceSchema = createInsertSchema(invoices).omit({ id: true, createdAt: true });
export const insertInvoiceItemSchema = createInsertSchema(invoiceItems).omit({ id: true });

export const insertDeliveryChallanSchema = createInsertSchema(deliveryChallans).omit({ id: true, createdAt: true });
export const insertDeliveryChallanItemSchema = createInsertSchema(deliveryChallanItems).omit({ id: true });

// === TYPES ===
export type Customer = typeof customers.$inferSelect;
export type InsertCustomer = z.infer<typeof insertCustomerSchema>;

export type Vendor = typeof vendors.$inferSelect;
export type InsertVendor = z.infer<typeof insertVendorSchema>;

export type Invoice = typeof invoices.$inferSelect;
export type InsertInvoice = z.infer<typeof insertInvoiceSchema>;
export type InvoiceItem = typeof invoiceItems.$inferSelect;
export type InsertInvoiceItem = z.infer<typeof insertInvoiceItemSchema>;

export type DeliveryChallan = typeof deliveryChallans.$inferSelect;
export type InsertDeliveryChallan = z.infer<typeof insertDeliveryChallanSchema>;
export type DeliveryChallanItem = typeof deliveryChallanItems.$inferSelect;
export type InsertDeliveryChallanItem = z.infer<typeof insertDeliveryChallanItemSchema>;

// Composite Types for API
export const createInvoiceWithItemsSchema = insertInvoiceSchema.extend({
  items: z.array(insertInvoiceItemSchema.omit({ invoiceId: true }))
});
export type CreateInvoiceRequest = z.infer<typeof createInvoiceWithItemsSchema>;

export const createChallanWithItemsSchema = insertDeliveryChallanSchema.extend({
  items: z.array(insertDeliveryChallanItemSchema.omit({ challanId: true }))
});
export type CreateChallanRequest = z.infer<typeof createChallanWithItemsSchema>;
