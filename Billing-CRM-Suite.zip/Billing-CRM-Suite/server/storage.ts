import { db } from "./db";
import {
  customers, vendors, invoices, invoiceItems, deliveryChallans, deliveryChallanItems,
  type Customer, type InsertCustomer,
  type Vendor, type InsertVendor,
  type Invoice, type CreateInvoiceRequest,
  type DeliveryChallan, type CreateChallanRequest,
  type InvoiceItem, type DeliveryChallanItem
} from "@shared/schema";
import { eq, desc } from "drizzle-orm";

export interface IStorage {
  // Customers
  getCustomers(): Promise<Customer[]>;
  getCustomer(id: number): Promise<Customer | undefined>;
  createCustomer(customer: InsertCustomer): Promise<Customer>;
  updateCustomer(id: number, customer: Partial<InsertCustomer>): Promise<Customer>;
  deleteCustomer(id: number): Promise<void>;

  // Vendors
  getVendors(): Promise<Vendor[]>;
  createVendor(vendor: InsertVendor): Promise<Vendor>;
  updateVendor(id: number, vendor: Partial<InsertVendor>): Promise<Vendor>;
  deleteVendor(id: number): Promise<void>;

  // Invoices
  getInvoices(): Promise<(Invoice & { customer?: Customer })[]>;
  getInvoice(id: number): Promise<(Invoice & { customer: Customer, items: InvoiceItem[] }) | undefined>;
  createInvoice(data: CreateInvoiceRequest): Promise<Invoice>;

  // Challans
  getChallans(): Promise<(DeliveryChallan & { customer?: Customer })[]>;
  getChallan(id: number): Promise<(DeliveryChallan & { customer: Customer, items: DeliveryChallanItem[] }) | undefined>;
  createChallan(data: CreateChallanRequest): Promise<DeliveryChallan>;
}

export class DatabaseStorage implements IStorage {
  // Customers
  async getCustomers(): Promise<Customer[]> {
    return await db.select().from(customers).orderBy(desc(customers.id));
  }

  async getCustomer(id: number): Promise<Customer | undefined> {
    const [customer] = await db.select().from(customers).where(eq(customers.id, id));
    return customer;
  }

  async createCustomer(insertCustomer: InsertCustomer): Promise<Customer> {
    const [customer] = await db.insert(customers).values(insertCustomer).returning();
    return customer;
  }

  async updateCustomer(id: number, updates: Partial<InsertCustomer>): Promise<Customer> {
    const [updated] = await db.update(customers).set(updates).where(eq(customers.id, id)).returning();
    return updated;
  }

  async deleteCustomer(id: number): Promise<void> {
    await db.delete(customers).where(eq(customers.id, id));
  }

  // Vendors
  async getVendors(): Promise<Vendor[]> {
    return await db.select().from(vendors).orderBy(desc(vendors.id));
  }

  async createVendor(insertVendor: InsertVendor): Promise<Vendor> {
    const [vendor] = await db.insert(vendors).values(insertVendor).returning();
    return vendor;
  }

  async updateVendor(id: number, updates: Partial<InsertVendor>): Promise<Vendor> {
    const [updated] = await db.update(vendors).set(updates).where(eq(vendors.id, id)).returning();
    return updated;
  }

  async deleteVendor(id: number): Promise<void> {
    await db.delete(vendors).where(eq(vendors.id, id));
  }

  // Invoices
  async getInvoices(): Promise<(Invoice & { customer?: Customer })[]> {
    return await db.query.invoices.findMany({
      with: { customer: true },
      orderBy: desc(invoices.id)
    });
  }

  async getInvoice(id: number): Promise<(Invoice & { customer: Customer, items: InvoiceItem[] }) | undefined> {
    const invoice = await db.query.invoices.findFirst({
      where: eq(invoices.id, id),
      with: {
        customer: true,
        items: true
      }
    });
    return invoice as (Invoice & { customer: Customer, items: InvoiceItem[] }) | undefined;
  }

  async createInvoice(data: CreateInvoiceRequest): Promise<Invoice> {
    // Transaction to create invoice and items
    return await db.transaction(async (tx) => {
      const { items, ...invoiceData } = data;
      
      const [invoice] = await tx.insert(invoices).values({
        ...invoiceData,
        date: new Date(invoiceData.date),
        dueDate: invoiceData.dueDate ? new Date(invoiceData.dueDate) : undefined,
      }).returning();

      if (items.length > 0) {
        await tx.insert(invoiceItems).values(
          items.map(item => ({
            ...item,
            invoiceId: invoice.id
          }))
        );
      }
      return invoice;
    });
  }

  // Challans
  async getChallans(): Promise<(DeliveryChallan & { customer?: Customer })[]> {
    return await db.query.deliveryChallans.findMany({
      with: { customer: true },
      orderBy: desc(deliveryChallans.id)
    });
  }

  async getChallan(id: number): Promise<(DeliveryChallan & { customer: Customer, items: DeliveryChallanItem[] }) | undefined> {
    const challan = await db.query.deliveryChallans.findFirst({
      where: eq(deliveryChallans.id, id),
      with: {
        customer: true,
        items: true
      }
    });
    return challan as (DeliveryChallan & { customer: Customer, items: DeliveryChallanItem[] }) | undefined;
  }

  async createChallan(data: CreateChallanRequest): Promise<DeliveryChallan> {
    return await db.transaction(async (tx) => {
      const { items, ...challanData } = data;
      
      const [challan] = await tx.insert(deliveryChallans).values({
        ...challanData,
        date: new Date(challanData.date),
      }).returning();

      if (items.length > 0) {
        await tx.insert(deliveryChallanItems).values(
          items.map(item => ({
            ...item,
            challanId: challan.id
          }))
        );
      }
      return challan;
    });
  }
}

export const storage = new DatabaseStorage();
