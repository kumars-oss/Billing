import { storage } from "./storage";

async function seed() {
  console.log("Seeding database...");

  // Customers
  const customers = await storage.getCustomers();
  if (customers.length === 0) {
    await storage.createCustomer({
      name: "Acme Corp",
      email: "contact@acme.com",
      phone: "555-0123",
      address: "123 Business Rd, Tech City",
      gstin: "27ABCDE1234F1Z5",
    });
    await storage.createCustomer({
      name: "Globex Inc",
      email: "info@globex.com",
      phone: "555-0987",
      address: "456 Industry Ln, Manufacturing Hub",
      gstin: "29XYZAB5678C1Z6",
    });
    console.log("Seeded customers");
  }

  // Vendors
  const vendors = await storage.getVendors();
  if (vendors.length === 0) {
    await storage.createVendor({
      name: "Office Supplies Co",
      email: "sales@officesupplies.com",
      phone: "555-1111",
      address: "789 Station St, Paper Town",
      gstin: "27PQRST9876G1Z2",
    });
    console.log("Seeded vendors");
  }

  // Invoices (Sample)
  const invoices = await storage.getInvoices();
  if (invoices.length === 0) {
    // Get the first customer
    const allCustomers = await storage.getCustomers();
    if (allCustomers.length > 0) {
      const customerId = allCustomers[0].id;
      await storage.createInvoice({
        customerId,
        number: "INV-2023-001",
        date: new Date(),
        dueDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000), // +7 days
        status: "Sent",
        totalAmount: "1500.00",
        items: [
          { description: "Web Development Services", quantity: 10, unitPrice: "100.00", amount: "1000.00" },
          { description: "Hosting Setup", quantity: 1, unitPrice: "500.00", amount: "500.00" },
        ],
      });
      console.log("Seeded invoices");
    }
  }

  console.log("Seeding complete!");
}

seed().catch(console.error);
