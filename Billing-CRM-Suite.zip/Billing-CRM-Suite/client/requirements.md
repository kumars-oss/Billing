## Packages
framer-motion | Smooth page transitions and layout animations
recharts | Dashboard charts and analytics
date-fns | Date formatting for invoices and challans
clsx | Conditional class names
tailwind-merge | Merging tailwind classes safely

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  sans: ["var(--font-sans)"],
  display: ["var(--font-display)"],
}
