import { Layout } from "@/components/Layout";
import { useChallans } from "@/hooks/use-challans";
import { Button } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Input } from "@/components/ui/input";
import { Plus, Search, Eye } from "lucide-react";
import { useState } from "react";
import { Link } from "wouter";
import { format } from "date-fns";

export default function Challans() {
  const { data: challans, isLoading } = useChallans();
  const [search, setSearch] = useState("");

  const filteredChallans = challans?.filter(c => 
    c.number.toLowerCase().includes(search.toLowerCase()) || 
    c.customer?.name.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <Layout>
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-8">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Delivery Challans</h2>
          <p className="text-muted-foreground mt-1">Track inventory movements</p>
        </div>
        <Link href="/challans/new">
          <Button className="shadow-lg shadow-primary/25">
            <Plus className="w-4 h-4 mr-2" />
            Create Challan
          </Button>
        </Link>
      </div>

      <div className="bg-card rounded-xl border border-border shadow-sm overflow-hidden">
        <div className="p-4 border-b border-border flex gap-4">
          <div className="relative flex-1 max-w-sm">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input 
              placeholder="Search by number or customer..." 
              className="pl-9 bg-muted/30"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
        </div>

        <Table>
          <TableHeader className="bg-muted/30">
            <TableRow>
              <TableHead>Challan #</TableHead>
              <TableHead>Customer</TableHead>
              <TableHead>Date</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="w-[80px]"></TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading ? (
              <TableRow>
                <TableCell colSpan={5} className="h-24 text-center">Loading...</TableCell>
              </TableRow>
            ) : filteredChallans?.length === 0 ? (
              <TableRow>
                <TableCell colSpan={5} className="h-32 text-center text-muted-foreground">
                  No delivery challans found.
                </TableCell>
              </TableRow>
            ) : (
              filteredChallans?.map((challan) => (
                <TableRow key={challan.id} className="hover:bg-muted/20">
                  <TableCell className="font-medium font-mono">{challan.number}</TableCell>
                  <TableCell>{challan.customer?.name || "Unknown Customer"}</TableCell>
                  <TableCell>{format(new Date(challan.date), "MMM d, yyyy")}</TableCell>
                  <TableCell>
                    <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${
                      challan.status === 'Delivered' ? 'bg-green-100 text-green-700' :
                      'bg-yellow-100 text-yellow-700'
                    }`}>
                      {challan.status}
                    </span>
                  </TableCell>
                  <TableCell>
                    <Button variant="ghost" size="icon" className="text-muted-foreground hover:text-primary">
                      <Eye className="w-4 h-4" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>
    </Layout>
  );
}
