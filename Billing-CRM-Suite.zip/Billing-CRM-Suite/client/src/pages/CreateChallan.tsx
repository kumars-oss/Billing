import { Layout } from "@/components/Layout";
import { useCustomers } from "@/hooks/use-customers";
import { useCreateChallan } from "@/hooks/use-challans";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent } from "@/components/ui/card";
import { Trash2, Plus, ArrowLeft, Save } from "lucide-react";
import { Link } from "wouter";
import { useFieldArray, useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { createChallanWithItemsSchema, type CreateChallanRequest } from "@shared/schema";
import { z } from "zod";

export default function CreateChallan() {
  const { data: customers } = useCustomers();
  const createChallan = useCreateChallan();
  
  const formSchema = createChallanWithItemsSchema.extend({
    items: z.array(z.object({
      description: z.string().min(1, "Description required"),
      quantity: z.coerce.number().min(1, "Quantity must be at least 1")
    })).min(1, "At least one item is required")
  });

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      date: new Date(),
      status: "Pending",
      items: [{ description: "", quantity: 1 }]
    }
  });

  const { fields, append, remove } = useFieldArray({
    control: form.control,
    name: "items"
  });

  const onSubmit = (data: z.infer<typeof formSchema>) => {
    createChallan.mutate(data);
  };

  return (
    <Layout>
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center gap-4 mb-8">
          <Link href="/challans">
            <Button variant="ghost" size="icon">
              <ArrowLeft className="w-4 h-4" />
            </Button>
          </Link>
          <div>
            <h2 className="text-3xl font-bold tracking-tight">New Delivery Challan</h2>
            <p className="text-muted-foreground">Create a delivery note for shipment</p>
          </div>
        </div>

        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
          <Card className="border-none shadow-md">
            <CardContent className="p-6 grid md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <Label>Customer</Label>
                <Select 
                  onValueChange={(val) => form.setValue("customerId", parseInt(val))}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select Customer" />
                  </SelectTrigger>
                  <SelectContent>
                    {customers?.map((c) => (
                      <SelectItem key={c.id} value={c.id.toString()}>{c.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {form.formState.errors.customerId && (
                  <p className="text-sm text-red-500">Customer is required</p>
                )}
              </div>
              
              <div className="space-y-2">
                <Label>Challan Number</Label>
                <Input {...form.register("number")} placeholder="DC-2024-001" />
                {form.formState.errors.number && (
                  <p className="text-sm text-red-500">{form.formState.errors.number.message}</p>
                )}
              </div>

              <div className="space-y-2">
                <Label>Date</Label>
                <Input type="date" {...form.register("date", { valueAsDate: true })} />
              </div>

              <div className="space-y-2">
                <Label>Status</Label>
                <Select 
                  defaultValue="Pending"
                  onValueChange={(val) => form.setValue("status", val)}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Pending">Pending</SelectItem>
                    <SelectItem value="Delivered">Delivered</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>

          <Card className="border-none shadow-md">
            <CardContent className="p-6">
              <div className="mb-4 flex items-center justify-between">
                <h3 className="text-lg font-semibold">Items</h3>
                <Button 
                  type="button" 
                  variant="outline" 
                  size="sm" 
                  onClick={() => append({ description: "", quantity: 1 })}
                >
                  <Plus className="w-4 h-4 mr-2" /> Add Item
                </Button>
              </div>

              <div className="space-y-4">
                {fields.map((field, index) => (
                  <div key={field.id} className="grid grid-cols-12 gap-4 items-end bg-muted/20 p-4 rounded-lg">
                    <div className="col-span-8 space-y-2">
                      <Label className="text-xs">Description</Label>
                      <Input {...form.register(`items.${index}.description`)} placeholder="Item name" />
                    </div>
                    <div className="col-span-3 space-y-2">
                      <Label className="text-xs">Quantity</Label>
                      <Input 
                        type="number" 
                        min="1"
                        {...form.register(`items.${index}.quantity`, { valueAsNumber: true })} 
                      />
                    </div>
                    <div className="col-span-1 flex justify-center pb-2">
                      <Button 
                        type="button" 
                        variant="ghost" 
                        size="icon" 
                        className="text-muted-foreground hover:text-destructive"
                        onClick={() => remove(index)}
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <div className="flex justify-end gap-4">
            <Link href="/challans">
              <Button type="button" variant="outline">Cancel</Button>
            </Link>
            <Button type="submit" size="lg" disabled={createChallan.isPending} className="shadow-lg shadow-primary/25">
              <Save className="w-4 h-4 mr-2" />
              {createChallan.isPending ? "Creating..." : "Create Challan"}
            </Button>
          </div>
        </form>
      </div>
    </Layout>
  );
}
