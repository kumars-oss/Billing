import { Layout } from "@/components/Layout";
import { StatCard } from "@/components/StatCard";
import { useInvoices } from "@/hooks/use-invoices";
import { useCustomers } from "@/hooks/use-customers";
import { useChallans } from "@/hooks/use-challans";
import { DollarSign, Users, FileText, Truck } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ResponsiveContainer, AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip } from "recharts";
import { Skeleton } from "@/components/ui/skeleton";

export default function Dashboard() {
  const { data: invoices, isLoading: loadingInvoices } = useInvoices();
  const { data: customers, isLoading: loadingCustomers } = useCustomers();
  const { data: challans, isLoading: loadingChallans } = useChallans();

  // Calculate stats
  const totalRevenue = invoices?.reduce((sum, inv) => sum + Number(inv.totalAmount), 0) || 0;
  const pendingInvoices = invoices?.filter(inv => inv.status === "Draft").length || 0;
  const totalCustomers = customers?.length || 0;
  const activeDeliveries = challans?.filter(c => c.status === "Pending").length || 0;

  // Mock data for chart - in a real app, this would come from the API grouped by date
  const chartData = [
    { name: "Jan", total: 1200 },
    { name: "Feb", total: 2100 },
    { name: "Mar", total: 800 },
    { name: "Apr", total: 1600 },
    { name: "May", total: 900 },
    { name: "Jun", total: 1700 },
  ];

  if (loadingInvoices || loadingCustomers || loadingChallans) {
    return (
      <Layout>
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4 mb-8">
          {[1, 2, 3, 4].map((i) => <Skeleton key={i} className="h-32 rounded-xl" />)}
        </div>
        <Skeleton className="h-[400px] rounded-xl" />
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="mb-8">
        <h2 className="text-3xl font-bold tracking-tight">Dashboard</h2>
        <p className="text-muted-foreground mt-1">Overview of your business metrics</p>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4 mb-8">
        <StatCard
          title="Total Revenue"
          value={`$${totalRevenue.toLocaleString()}`}
          icon={DollarSign}
          description="Lifetime revenue"
          trend="up"
          trendValue="+12.5%"
        />
        <StatCard
          title="Pending Invoices"
          value={pendingInvoices}
          icon={FileText}
          description="Awaiting payment"
        />
        <StatCard
          title="Total Customers"
          value={totalCustomers}
          icon={Users}
          description="Active client base"
          trend="up"
          trendValue="+4"
        />
        <StatCard
          title="Pending Deliveries"
          value={activeDeliveries}
          icon={Truck}
          description="Processing challans"
        />
      </div>

      <div className="grid gap-6 md:grid-cols-7">
        <Card className="col-span-4 border-none shadow-md">
          <CardHeader>
            <CardTitle>Revenue Overview</CardTitle>
          </CardHeader>
          <CardContent className="pl-2">
            <div className="h-[300px]">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={chartData}>
                  <defs>
                    <linearGradient id="colorTotal" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.3}/>
                      <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <XAxis dataKey="name" stroke="#888888" fontSize={12} tickLine={false} axisLine={false} />
                  <YAxis stroke="#888888" fontSize={12} tickLine={false} axisLine={false} tickFormatter={(value) => `$${value}`} />
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#eee" />
                  <Tooltip 
                    contentStyle={{ backgroundColor: 'white', borderRadius: '8px', border: 'none', boxShadow: '0 4px 12px rgba(0,0,0,0.1)' }}
                  />
                  <Area type="monotone" dataKey="total" stroke="hsl(var(--primary))" strokeWidth={2} fillOpacity={1} fill="url(#colorTotal)" />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        <Card className="col-span-3 border-none shadow-md">
          <CardHeader>
            <CardTitle>Recent Invoices</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {invoices?.slice(0, 5).map((invoice) => (
                <div key={invoice.id} className="flex items-center justify-between border-b border-border/50 last:border-0 pb-4 last:pb-0">
                  <div className="space-y-1">
                    <p className="text-sm font-medium leading-none">{invoice.number}</p>
                    <p className="text-xs text-muted-foreground">{invoice.customer?.name || "Unknown Customer"}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-bold text-foreground">${Number(invoice.totalAmount).toLocaleString()}</p>
                    <span className="text-[10px] bg-primary/10 text-primary px-2 py-0.5 rounded-full font-medium">
                      {invoice.status}
                    </span>
                  </div>
                </div>
              ))}
              {(!invoices || invoices.length === 0) && (
                <div className="text-center py-8 text-muted-foreground text-sm">No recent invoices</div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </Layout>
  );
}
