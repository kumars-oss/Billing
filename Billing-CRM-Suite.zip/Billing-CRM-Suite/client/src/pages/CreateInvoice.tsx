import { Layout } from "@/components/Layout";
import { useCustomers } from "@/hooks/use-customers";
import { useCreateInvoice } from "@/hooks/use-invoices";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent } from "@/components/ui/card";
import { Trash2, Plus, ArrowLeft, Save } from "lucide-react";
import { Link } from "wouter";
import { useState } from "react";
import { useFieldArray, useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { createInvoiceWithItemsSchema, type CreateInvoiceRequest } from "@shared/schema";
import { z } from "zod";

export default function CreateInvoice() {
  const { data: customers } = useCustomers();
  const createInvoice = useCreateInvoice();
  
  // Extend schema for form handling (need strings for numeric inputs, will coerce later)
  const formSchema = createInvoiceWithItemsSchema.extend({
    items: z.array(z.object({
      description: z.string().min(1, "Description required"),
      quantity: z.coerce.number().min(1, "Quantity must be at least 1"),
      unitPrice: z.coerce.number().min(0, "Price must be positive"),
      amount: z.coerce.number() // Calculated field
    })).min(1, "At least one item is required")
  });

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      date: new Date(),
      status: "Draft",
      totalAmount: "0",
      items: [{ description: "", quantity: 1, unitPrice: 0, amount: 0 }]
    }
  });

  const { fields, append, remove } = useFieldArray({
    control: form.control,
    name: "items"
  });

  // Calculate row total and grand total
  const watchItems = form.watch("items");
  const totalAmount = watchItems.reduce((sum, item) => sum + (item.quantity * item.unitPrice), 0);
  
  // Keep calculated amount in sync visually (not strictly needed for submission but good for UI)
  
  const onSubmit = (data: z.infer<typeof formSchema>) => {
    // Transform data for API
    const apiData: CreateInvoiceRequest = {
      ...data,
      totalAmount: totalAmount.toString(),
      items: data.items.map(item => ({
        ...item,
        amount: (item.quantity * item.unitPrice).toString(),
        unitPrice: item.unitPrice.toString()
      }))
    };
    
    createInvoice.mutate(apiData);
  };

  return (
    <Layout>
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center gap-4 mb-8">
          <Link href="/invoices">
            <Button variant="ghost" size="icon">
              <ArrowLeft className="w-4 h-4" />
            </Button>
          </Link>
          <div>
            <h2 className="text-3xl font-bold tracking-tight">New Invoice</h2>
            <p className="text-muted-foreground">Create a new invoice for a customer</p>
          </div>
        </div>

        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
          <Card className="border-none shadow-md">
            <CardContent className="p-6 grid md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <Label>Customer</Label>
                <Select 
                  onValueChange={(val) => form.setValue("customerId", parseInt(val))}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select Customer" />
                  </SelectTrigger>
                  <SelectContent>
                    {customers?.map((c) => (
                      <SelectItem key={c.id} value={c.id.toString()}>{c.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {form.formState.errors.customerId && (
                  <p className="text-sm text-red-500">Customer is required</p>
                )}
              </div>
              
              <div className="space-y-2">
                <Label>Invoice Number</Label>
                <Input {...form.register("number")} placeholder="INV-2024-001" />
                {form.formState.errors.number && (
                  <p className="text-sm text-red-500">{form.formState.errors.number.message}</p>
                )}
              </div>

              <div className="space-y-2">
                <Label>Date</Label>
                <Input type="date" {...form.register("date", { valueAsDate: true })} />
              </div>

              <div className="space-y-2">
                <Label>Due Date</Label>
                <Input type="date" {...form.register("dueDate", { valueAsDate: true })} />
              </div>
            </CardContent>
          </Card>

          <Card className="border-none shadow-md">
            <CardContent className="p-6">
              <div className="mb-4 flex items-center justify-between">
                <h3 className="text-lg font-semibold">Items</h3>
                <Button 
                  type="button" 
                  variant="outline" 
                  size="sm" 
                  onClick={() => append({ description: "", quantity: 1, unitPrice: 0, amount: 0 })}
                >
                  <Plus className="w-4 h-4 mr-2" /> Add Item
                </Button>
              </div>

              <div className="space-y-4">
                {fields.map((field, index) => {
                  const qty = form.watch(`items.${index}.quantity`) || 0;
                  const price = form.watch(`items.${index}.unitPrice`) || 0;
                  const amount = qty * price;

                  return (
                    <div key={field.id} className="grid grid-cols-12 gap-4 items-end bg-muted/20 p-4 rounded-lg">
                      <div className="col-span-5 space-y-2">
                        <Label className="text-xs">Description</Label>
                        <Input {...form.register(`items.${index}.description`)} placeholder="Item name" />
                      </div>
                      <div className="col-span-2 space-y-2">
                        <Label className="text-xs">Qty</Label>
                        <Input 
                          type="number" 
                          min="1"
                          {...form.register(`items.${index}.quantity`, { valueAsNumber: true })} 
                        />
                      </div>
                      <div className="col-span-2 space-y-2">
                        <Label className="text-xs">Price</Label>
                        <Input 
                          type="number" 
                          min="0"
                          step="0.01"
                          {...form.register(`items.${index}.unitPrice`, { valueAsNumber: true })} 
                        />
                      </div>
                      <div className="col-span-2 space-y-2">
                        <Label className="text-xs">Amount</Label>
                        <div className="h-10 flex items-center px-3 bg-muted rounded-md text-sm font-medium">
                          ${amount.toFixed(2)}
                        </div>
                      </div>
                      <div className="col-span-1 flex justify-center pb-2">
                        <Button 
                          type="button" 
                          variant="ghost" 
                          size="icon" 
                          className="text-muted-foreground hover:text-destructive"
                          onClick={() => remove(index)}
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  );
                })}
              </div>

              <div className="mt-8 flex justify-end">
                <div className="w-64 space-y-3">
                  <div className="flex justify-between text-lg font-bold">
                    <span>Total</span>
                    <span>${totalAmount.toFixed(2)}</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <div className="flex justify-end gap-4">
            <Link href="/invoices">
              <Button type="button" variant="outline">Cancel</Button>
            </Link>
            <Button type="submit" size="lg" disabled={createInvoice.isPending} className="shadow-lg shadow-primary/25">
              <Save className="w-4 h-4 mr-2" />
              {createInvoice.isPending ? "Creating..." : "Create Invoice"}
            </Button>
          </div>
        </form>
      </div>
    </Layout>
  );
}
