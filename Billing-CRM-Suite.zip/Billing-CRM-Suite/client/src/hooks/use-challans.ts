import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";
import { type CreateChallanRequest } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from "wouter";

export function useChallans() {
  return useQuery({
    queryKey: [api.challans.list.path],
    queryFn: async () => {
      const res = await fetch(api.challans.list.path);
      if (!res.ok) throw new Error("Failed to fetch challans");
      return api.challans.list.responses[200].parse(await res.json());
    },
  });
}

export function useChallan(id: number) {
  return useQuery({
    queryKey: [api.challans.get.path, id],
    queryFn: async () => {
      const url = buildUrl(api.challans.get.path, { id });
      const res = await fetch(url);
      if (res.status === 404) return null;
      if (!res.ok) throw new Error("Failed to fetch challan");
      return api.challans.get.responses[200].parse(await res.json());
    },
    enabled: !!id,
  });
}

export function useCreateChallan() {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const [, setLocation] = useLocation();

  return useMutation({
    mutationFn: async (data: CreateChallanRequest) => {
      const res = await fetch(api.challans.create.path, {
        method: api.challans.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      
      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.message || "Failed to create challan");
      }
      return api.challans.create.responses[201].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.challans.list.path] });
      toast({ title: "Success", description: "Delivery Challan created successfully" });
      setLocation("/challans");
    },
    onError: (error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });
}
